-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 15, 2024 at 10:22 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `katalog`
--

-- --------------------------------------------------------

--
-- Table structure for table `budaya`
--

CREATE TABLE `budaya` (
  `id_budaya` int(11) NOT NULL,
  `id_kategori` int(11) NOT NULL,
  `id_provinsi` int(11) NOT NULL,
  `nama_budaya` varchar(100) NOT NULL,
  `deskripsi` text DEFAULT NULL,
  `gambar` blob DEFAULT NULL,
  `link_video` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `budaya`
--

INSERT INTO `budaya` (`id_budaya`, `id_kategori`, `id_provinsi`, `nama_budaya`, `deskripsi`, `gambar`, `link_video`) VALUES
(1, 1, 1, 'Tari Saman', 'Tari Saman adalah salah satu tarian tradisional yang berasal dari Aceh, Indonesia. Tarian ini dikenal dengan gerakan yang cepat, dinamis, dan ritmis, diiringi oleh nyanyian bersama yang dilakukan oleh penari. Biasanya, Tari Saman dibawakan oleh sekelompok penari laki-laki, meskipun kini juga sering dipentaskan oleh penari perempuan. Tarian ini mengandung nilai-nilai kebersamaan, kekompakan, dan solidaritas. Gerakan tangan, tubuh, dan kepala yang serempak serta suara tepukan tangan yang melengkapi ritme musik membuat Tari Saman menjadi pertunjukan yang energik dan memukau.', 0xffd8ffe000104a46494600010101004800480000ffdb00430006040506050406060506070706080a100a0a09090a140e0f0c1017141818171416161a1d251f1a1b231c1616202c20232627292a29191f2d302d283025282928ffdb0043010707070a080a130a0a13281a161a2828282828282828282828282828282828282828282828282828282828282828282828282828282828282828282828282828ffc00011080028003c03012200021101031101ffc4001f0000010501010101010100000000000000000102030405060708090a0bffc400b5100002010303020403050504040000017d01020300041105122131410613516107227114328191a1082342b1c11552d1f02433627282090a161718191a25262728292a3435363738393a434445464748494a535455565758595a636465666768696a737475767778797a838485868788898a92939495969798999aa2a3a4a5a6a7a8a9aab2b3b4b5b6b7b8b9bac2c3c4c5c6c7c8c9cad2d3d4d5d6d7d8d9dae1e2e3e4e5e6e7e8e9eaf1f2f3f4f5f6f7f8f9faffc4001f0100030101010101010101010000000000000102030405060708090a0bffc400b51100020102040403040705040400010277000102031104052131061241510761711322328108144291a1b1c109233352f0156272d10a162434e125f11718191a262728292a35363738393a434445464748494a535455565758595a636465666768696a737475767778797a82838485868788898a92939495969798999aa2a3a4a5a6a7a8a9aab2b3b4b5b6b7b8b9bac2c3c4c5c6c7c8c9cad2d3d4d5d6d7d8d9dae2e3e4e5e6e7e8e9eaf2f3f4f5f6f7f8f9faffda000c03010002110311003f00f99e351561545409d2a5527d6bd98e6718e8d0b9192aaafe34e540c70319a8d49ed4f524f4eb55fda9092b490f91922c39da1012c7b530c78ed4f5738a42fe95d50c650e556138cae56994671c66ab320cd5c9083d403503633d057154ae9cdcb4f21f28d535d3e9fe18b9d45a2974e8e4bbb7742e5615cc919c742bcfe6323d7159da5c32471b0934a82f33ca990b82a7db6b0cfe39af438a513dee906db4cb4d3e792060df64fdd34cd8c63e56f4c1c0fc735e0ce5caae7452b4ea2a7dce1edf4602e1aceee648750704471364ec23b3e3382467e9df1569bc25aa476d14b2c12400ee333dc218e2854630c5cf04376c75ed9ae9b45f0de953f881a4babb1713bcb8b7b3b59944a324ec24b615986304658e7a8e6a4d4b54bad53c316fa66a572d168915c791123363e5561f7189624af72370038ee2a799df42dc2efdcd4e5acfc3ef78d0be9d235dc4cdb24f254974c1c17da403b09e87d3ae291b425b4982eab39b36924f2e249233bf1d048c3b2e71ee7b035df431e97a359e91158e8dfd9d789724aeaa2f7789a30a7e607807231c81c10702aa6a969a4bf8e153535b9be9662a2692e1708f31180bb8003037053dcb0eb571aab66692a29439daeb639bb4f00eb379677935ada7dae38f0239e0957cb63919c938c71eb8ae6eef4d82da631cda95a1900f98441e40a7d3705c13f4247bd77536af77a6dceb5a5d8dccb616773f21b75649720800ee3c9278c7249e9c8af347d36f15b0c0e7eb5a424dee73558f249c3b1d0e9de2f48405921e3fdcadad3bc59e1b86d5ad4e98c904a33288d59777b1c1e47b74a28a25aee6318456b6174fd7fc196f78246d2366d60cac04990474239e0fd2afea7aff00842f424d358179d881b9da563b076049e076a28a97dcd6296c584f12f8192c45b258bf92cc19a12b294c8efb7a66997de29f06c933aad83c91492995cb2ca7731ce5883df93cf5a28ad232681caeb632f51f10785269de55d24336edc1fcb6249eb924f7fad625cf8bad9a5252c942f6f9714515a2ad326493773fffd9, 'https://youtu.be/vzit4ewJdb8?si=JKf8BobgWRMAxCGQ'),
(2, 1, 1, 'Tari Seudati', 'Tari Seudati adalah tari tradisional yang berasal dari Aceh, Indonesia. Tarian ini biasanya dibawakan oleh sekelompok penari pria yang menggunakan gerakan cepat dan enerjik. Seudati diiringi oleh musik tradisional berupa gendang dan nyanyian yang diulang-ulang, dengan tema yang berkaitan dengan perjuangan, keberanian, dan keagamaan. Gerakan dalam Tari Seudati melibatkan pukulan tangan, tepukan, dan gerak tubuh yang kompak, menciptakan kesan kuat dan tegas. Selain sebagai hiburan, Tari Seudati juga memiliki makna spiritual dan sering dipentaskan dalam berbagai upacara adat di Aceh.', 0xffd8ffe000104a46494600010101006000600000ffdb00430006040506050406060506070706080a100a0a09090a140e0f0c1017141818171416161a1d251f1a1b231c1616202c20232627292a29191f2d302d283025282928ffdb0043010707070a080a130a0a13281a161a2828282828282828282828282828282828282828282828282828282828282828282828282828282828282828282828282828ffc00011080027004603012200021101031101ffc4001f0000010501010101010100000000000000000102030405060708090a0bffc400b5100002010303020403050504040000017d01020300041105122131410613516107227114328191a1082342b1c11552d1f02433627282090a161718191a25262728292a3435363738393a434445464748494a535455565758595a636465666768696a737475767778797a838485868788898a92939495969798999aa2a3a4a5a6a7a8a9aab2b3b4b5b6b7b8b9bac2c3c4c5c6c7c8c9cad2d3d4d5d6d7d8d9dae1e2e3e4e5e6e7e8e9eaf1f2f3f4f5f6f7f8f9faffc4001f0100030101010101010101010000000000000102030405060708090a0bffc400b51100020102040403040705040400010277000102031104052131061241510761711322328108144291a1b1c109233352f0156272d10a162434e125f11718191a262728292a35363738393a434445464748494a535455565758595a636465666768696a737475767778797a82838485868788898a92939495969798999aa2a3a4a5a6a7a8a9aab2b3b4b5b6b7b8b9bac2c3c4c5c6c7c8c9cad2d3d4d5d6d7d8d9dae2e3e4e5e6e7e8e9eaf2f3f4f5f6f7f8f9faffda000c03010002110311003f00f97a7b2b882d6dee2589960b804c4fd9b0707f5aaf464e29db18a938e075a4bcc06d2aa96600724f4a7c70c924a234525c9c018e6aee8b6e24d7ad2076e0ce14b273dfb53d07665ad37c357b7ec046d0a0cf25d8803f4c54faa785e5d3a3dd35c239c670855bf9367f4af5fd23c26f6b6df6d81e731793f6b81a2f91e44cf3b738c329c0f6054f7aebbc63e103aaf86a0f26eaeeeee248b7c7f69fbea48c80c7bf5c722afdd5b912e68eacf94ca633d78a65777e21f094fa4685f69990190ca532a720e3a9fa76fc0d6ee9bf097c452e8f63717165f664910dcc333b23c726e00a86cf0a48c707e86a1ec9aea68a3ab4fa1e4f455bd5a28adefe58608a78846763a4e417571c30380075cd1412751f0fbc3d677fe28b5835eb87b5b36c8dd19058b1e00e410064f24f615ea3a57833c1b6da0eb7677b15ddc4f7174be45c3960d691b1299ea14b210cc49037022b8cf85da7c83c43a41d52d9fecbe7a890b92bb413d723918e0d7a258dad945e11f17c32b2b5ec9a87fa23b025a48f39247b1c633ef594bda737bb6b1b41d34bdebfc8d2bdf0cfc3ad5351d02ef46866d3cdbb24b7125c48e0cd1a80ae837139655c302383b48e77573777a0e849f1f7ed46ded2dbc368cbb628ed480488400447b76925f19cf1c93d69fe30d3e09a1f00c9a5c51f9c857fb4218e4f9b865c961d41233c718c6455abdd19dbe3b69cb6714234f4b98810921210c912ee23d0066269255bbafeb6ff008268de1dabfbd7f97cfe67a8e97e22f0f25ede43225b49a65bc8b15bc1142372bf97b78439c021581eb9156ac7c4ba25e69d26b0daa7931dafefd6cc22c4cdb490aa179c82531f2e39041af30b7d2a3b1f88dabd9cf6aad0dc69863861121223b8d8926ec039c1dac3b751daa86ab10d3fe2f456b2c11ff61adf987c867da042cc720f3bb00b9249e78a7155ee9c9ad873faa5ad1527af5b6dfe6755f127c63a3789ad5b4b5b786029224b12dc109f2fcc5871d092bb4f5e0fa9aa5ab78dbfb4fc0d2687736325adb3030acc72c506e055b0070157191dc0e08e8785f1fd8ce7c3fe1ad4aca0f26fae12e8dcb29f9b2273b4e09f438e3d0e6bd4bc7ba9497df0dfc456e862b77b6b2d322130e0b863f37cddf3b7a7a014b92b4a9a4e767e437570b1a926a0dc5ed776b3f91f34eb1e1db3d3e41f69bfc3331c9033cff5a28f14c3e54702db0f3324f28dbf6803a647d68ad55eda9cacfa0a38acb438d6fe75221b760e768c9ebc7eb51f837c511ebdfdab6fe4f9464712a03ce063bfa9396fca8a2a3ecb65534a4ecfcff23ae9e04686c155549518638f714e96d61fed9406188c6cca59368c1f5e28a284c9b17e38ade2b990436f147b806f9540c7cbff00d7a8af21b7f36455894b3b9de48c93cf524f24f3de8a2aae231357b6b5920b69668124c12aa8df75707390bd013b8f3591ad68e971a6de46d34e60fdc4d247bf87daacaa3d4001b800e39a28a7d467192e976b1208e1458d41e8ab8a28a2a0bb1fffd9, 'https://youtu.be/-3jZ_gyjVf4?si=5B4MiZJNccYAa1Ia'),
(3, 2, 1, 'Mie Aceh', 'Mie Aceh adalah hidangan mie pedas khas Aceh yang terkenal dengan bumbu kaya rempah. Berikut resep singkatnya:\r\na. Bahan-bahan:\r\n200g mie telur\r\n100g daging sapi atau ayam, potong kecil\r\n2 butir telur\r\n2 sdm minyak goreng\r\n2 batang daun bawang, iris\r\n1 buah tomat, potong\r\n1 sdm saus sambal\r\n1 sdt air asam\r\n1 sdt kecap manis\r\nBumbu halus: 5 siung bawang merah, 3 siung bawang putih, 3 buah cabai merah, 1 sdt jintan, 1 sdt ketumbar, 1 cm jahe, 1 cm lengkuas\r\nGaram dan merica secukupnya\r\n\r\nb. Cara memasak:\r\n1. Rebus mie telur hingga matang, tiriskan.\r\n2. Tumis bumbu halus dengan minyak goreng hingga harum.\r\n3. Masukkan daging, aduk hingga berubah warna.\r\n4. Tambahkan tomat, daun bawang, saus sambal, air asam, kecap manis, garam, dan merica. Aduk rata.\r\n5. Masukkan mie yang sudah direbus, aduk hingga tercampur rata.\r\n6. Tambahkan telur, aduk lagi hingga matang.\r\n7. Sajikan mie Aceh dengan taburan bawang goreng dan sambal.', 0xffd8ffe000104a46494600010101006000600000ffdb00430006040506050406060506070706080a100a0a09090a140e0f0c1017141818171416161a1d251f1a1b231c1616202c20232627292a29191f2d302d283025282928ffdb0043010707070a080a130a0a13281a161a2828282828282828282828282828282828282828282828282828282828282828282828282828282828282828282828282828ffc00011080032004603012200021101031101ffc4001f0000010501010101010100000000000000000102030405060708090a0bffc400b5100002010303020403050504040000017d01020300041105122131410613516107227114328191a1082342b1c11552d1f02433627282090a161718191a25262728292a3435363738393a434445464748494a535455565758595a636465666768696a737475767778797a838485868788898a92939495969798999aa2a3a4a5a6a7a8a9aab2b3b4b5b6b7b8b9bac2c3c4c5c6c7c8c9cad2d3d4d5d6d7d8d9dae1e2e3e4e5e6e7e8e9eaf1f2f3f4f5f6f7f8f9faffc4001f0100030101010101010101010000000000000102030405060708090a0bffc400b51100020102040403040705040400010277000102031104052131061241510761711322328108144291a1b1c109233352f0156272d10a162434e125f11718191a262728292a35363738393a434445464748494a535455565758595a636465666768696a737475767778797a82838485868788898a92939495969798999aa2a3a4a5a6a7a8a9aab2b3b4b5b6b7b8b9bac2c3c4c5c6c7c8c9cad2d3d4d5d6d7d8d9dae2e3e4e5e6e7e8e9eaf2f3f4f5f6f7f8f9faffda000c03010002110311003f00af6971a97c43babbd4a093ec30a158ed84a819dd54b105f1e9b88ae7fc517de26f0f6af169d3491de34b1ee54851802093db27d2bbcd3605f03f87a18e353338214e4fccd5a5e0df16da6adac1f36148ee63859995b390a0fb81eb5f1346b375b9e2af1febe67d3cf1b4b0cfd9fda5b2feb4386f0fdaf8df4f0d2ca45b59dc36e0b704b1fa2afde07d80fad779676515b2a2de5d79f7523077c9c0cfd32703ff00af5d2dadfd8dfdd34f32dbef55644246368efcfbe3f9571faf597db353920b2824ff0047e3284c71939eee3a91d71f4a9c74f9e29caca270d6c7e2172a847de7f7b33fc496fa6b5da94d2ad6fa4da0a168832a9cf527a7e7eb5565d163bef0bde58d9d9a5b3de46c876312a59875ce3a7e75a36fe1d24c904dab496f9037c6724c849e0f5cfa0e7a75ac9fed068af3ec57534f1bdbe763bb79640071b413c30ef83e86b9b0f5250d62ee704eae270f373ae9bbedaff91c6f8874cf12f87f4102fb4892e2d542e6e6df2e5001ce3a11d3ae315ca785e681eeeeee358d28b452a911c52f3c92318cf23183f9d7d3f6faa457da7047476909e41c37d3a71d2b9df16e87a66a8b1f9e8e2ee30423af51dceef5af6a388872d9753d0ad57135a29a7f26784cfa5e91f6b2f3e9f0c68cbc2a82a01fce8a8bc45637361a8cb6d3805d1b861d083d08cd15d31e66b493fbcf1bdbce2da96e7b5f892c74cd234b922d66eeee733a990dc16dcc6538da08c1f9701ab1d7c3f2a6891ea1a644c91c51133bc64192e0119214e70ab8233edcd5ef886f1dce9d0cd14922dbcc63dedb4b08d406c9f7fa7a81ea2b461f1d785edf4cb6d1acb545bd97caf2922dafb88c632c703079e9d6bccc2df91b4b53da94fd9e29c92f7acacffc8b9e1ad2a7d46ddae6def5574f9137bacb1efec3eeb06191c0e9eff87492dc5858c90443cb9efa340e207652d129e0139cf7fe7f8d78c7dab538ad26fb046618a25dae52512ca3927cb50090b81ddb3c7ad6a6bfabda6892a5ac69766cae543b0321323b76c907a824823392471d2b8ead39d695deafa1ead4d5de4ffaf534758f146a32dd2b5ce9935c441df74f26c88851c9daaa72571c8ce78fad74571a969ba8304d712d6fa392153160f386fe2031c118c7b62bceb4eba82790dd5bc1716f6b6fe60512c849deca06de4e7f857a83d38cd73302eaf6174649b506fb2bbffab92431842c32a0a9218f27a1f9867354b0dceef7b4a3f8fe6673517a35a1ebd24b69a45b491e912927eec7bdc9619e096fa73fa54da64c9676686790f4cb48e704fe75c4780ec65bef145e4575fbbbbf2c845338652323241eb9e338e0f26ba2d4b4459ef0837534b83c820e0574c69ca094af7309f2df90f3af8b1e5a5d5adeda3890cf9126e7cf3dbafe3456ef8eb58b3f0d43656d73a7c57d24b9654915502aaf7cb0c67e6e9f5a2bd8c3d393a69f2dcf07134a0eab7cd62a6a9aa486cdf4abd7cca1b6c13f7c120b211f8023dc62b9dd1e73a66a6e55a11236156565e01041c13d81e84d743f133c33750ccd7d6adb5e36120da3827afafa570f777da6c97440b98949e70cd8c67b735c34a95e368f5dce9c74a50a90ad15b1e8b677da85f59db4967a6fd9d183accbe632bc6dedc03838ebc531e5b9fb395b78edf53bace20fb545180c093b89dc303681ce0f24fae6b93b1d56f6d743bab7d32566858fcd2062e23523ee820e147538fa7a0c518f5058ace678e2fb1c808dc9128984e38c925f9ce79ffebf359ac26beee9aff57d6ff77fc13b61995392f79d9ff5f237751bed42e2d56e2fae6113abe2dfcb88b24e493fba44e33c9521863a67d09dcd2f52786f9ac34fb5b6bad555035d5d3a054b756e814f27f9e79e6b97b43a2abc37fab6ada84b744a32f9a85ca800f0a074ebd0f4c535ee9aecccfe19b2d44dc7cc3ed42d95c31ce46feb81d700f4c8f4029cf0ea6ac969e965fe76fd4e98e2a115a3bbfbcbfe20d7a2d03c4915eb44b730c4e18a444011938e0376271c03e95dfdc7c48f0bff0066477706a5b0b1456819733a64f395ebc7393cfb66bc92df46f1b6ab70cb7b09f2d4e59a5545049efeff00fd61526a1e1dd2fc3ac26f116a40cd2107cb89499327b9cf38fa8fd78ae98aa104a9b777e5adff000386ad4ad524e508d979e88b5f1535b83c53aad926945ae6d6d22602531b29666233c6338185ea077a2b8ad6b503ad5e3c1e1db292dece3c36d524bbe380cc73efc0f73457a34d72c526d47c9ee79f3a1ed24e5abf4d8fa63e222a9b39f2a3a3f6f615f2a789942ead385000dc47028a2b9b2dfe248edc57f0d1534cb99ed6f6292da696170dc346e548fc457d49e068a3d4741dba84697432389d43ff003a28a599ee830bfc3674b67a4e9d6c85adac2d216dbd638554fe82b3f51450b12851b7cc0b8c718f4a28af9eadfc447a786f80c1d66592092610bbc616ddd86c38c118c1af98efe796e6f2496e659259598967918b13cf7268a2bd7c8be299c99a7c28edfc0202683712200ae6e02961c1236f4cd1451538dfe3c8d709fc189fffd9, '-');

-- --------------------------------------------------------

--
-- Table structure for table `favorit`
--

CREATE TABLE `favorit` (
  `id_favorit` int(11) NOT NULL,
  `id_budaya` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `favorit`
--

INSERT INTO `favorit` (`id_favorit`, `id_budaya`) VALUES
(15, 2);

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `id_kategori` int(11) NOT NULL,
  `nama_kategori` enum('Tarian Daerah','Makanan Khas','Alat Musik','Pakaian') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `nama_kategori`) VALUES
(1, 'Tarian Daerah'),
(2, 'Makanan Khas'),
(3, 'Alat Musik'),
(4, 'Pakaian');

-- --------------------------------------------------------

--
-- Table structure for table `pengguna`
--

CREATE TABLE `pengguna` (
  `id_user` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','user') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pengguna`
--

INSERT INTO `pengguna` (`id_user`, `username`, `email`, `password`, `role`) VALUES
(1, 'icha', 'itscha@gmail.com', 'icha2811', 'user'),
(2, 'admin', 'adminbudaya@gmail.com', 'admin123', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `provinsi`
--

CREATE TABLE `provinsi` (
  `id_provinsi` int(11) NOT NULL,
  `nama_provinsi` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `provinsi`
--

INSERT INTO `provinsi` (`id_provinsi`, `nama_provinsi`) VALUES
(1, 'Aceh'),
(2, 'Bali'),
(3, 'Banten'),
(4, 'Bengkulu'),
(5, 'Gorontalo'),
(6, 'Jambi'),
(7, 'Jawa Barat'),
(8, 'Jawa Tengah'),
(9, 'Jawa Timur'),
(10, 'Kalimantan Barat'),
(11, 'Kalimantan Selatan'),
(12, 'Kalimantan Tengah'),
(13, 'Kalimantan Timur'),
(14, 'Kalimantan Utara'),
(15, 'Lampung'),
(16, 'Maluku'),
(17, 'Nusa Tenggara Barat'),
(18, 'Nusa Tenggara Timur'),
(19, 'Papua'),
(20, 'Riau'),
(21, 'Sulawesi Barat'),
(22, 'Sulawesi Selatan'),
(23, 'Sulawesi Tengah'),
(24, 'Sulawesi Tenggara'),
(25, 'Sulawesi Utara'),
(26, 'Sumatera Barat'),
(27, 'Sumatera Selatan'),
(28, 'Sumatera Utara');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `budaya`
--
ALTER TABLE `budaya`
  ADD PRIMARY KEY (`id_budaya`),
  ADD KEY `id_kategori` (`id_kategori`),
  ADD KEY `id_provinsi` (`id_provinsi`);

--
-- Indexes for table `favorit`
--
ALTER TABLE `favorit`
  ADD PRIMARY KEY (`id_favorit`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`id_kategori`);

--
-- Indexes for table `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`id_user`);

--
-- Indexes for table `provinsi`
--
ALTER TABLE `provinsi`
  ADD PRIMARY KEY (`id_provinsi`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `budaya`
--
ALTER TABLE `budaya`
  MODIFY `id_budaya` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `favorit`
--
ALTER TABLE `favorit`
  MODIFY `id_favorit` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `id_kategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `pengguna`
--
ALTER TABLE `pengguna`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `provinsi`
--
ALTER TABLE `provinsi`
  MODIFY `id_provinsi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `budaya`
--
ALTER TABLE `budaya`
  ADD CONSTRAINT `budaya_ibfk_1` FOREIGN KEY (`id_kategori`) REFERENCES `kategori` (`id_kategori`),
  ADD CONSTRAINT `budaya_ibfk_2` FOREIGN KEY (`id_provinsi`) REFERENCES `provinsi` (`id_provinsi`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
