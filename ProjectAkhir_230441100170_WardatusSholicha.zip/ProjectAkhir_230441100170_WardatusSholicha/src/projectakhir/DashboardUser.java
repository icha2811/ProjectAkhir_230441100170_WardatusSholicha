/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package projectakhir;

import java.awt.CardLayout;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import java.sql.SQLException;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.table.DefaultTableModel;

public class DashboardUser extends javax.swing.JFrame {
    private DefaultTableModel tableModelFavorit;
    private ResultSet rsHasilPencarian;
    JTabbedPane tabbedPane = new JTabbedPane();

    

    public DashboardUser() {
        initComponents();
        loadKategoriProvinsi();

    taDesk = new JTextArea();
    taDesk.setLineWrap(true);
    taDesk.setWrapStyleWord(true);
    taDesk.setPreferredSize(new java.awt.Dimension(220, 100));
    jScrollPane1.setViewportView(taDesk);

    taLink = new JTextArea();
    taLink.setLineWrap(true);
    taLink.setWrapStyleWord(true);
    taLink.setPreferredSize(new java.awt.Dimension(220, 50));
    jScrollPane2.setViewportView(taLink);


        
        // Asumsi panel Katalog dan Detail sudah dideklarasikan di initComponents() tabbedPane = new JTabbedPane();
        
        // Membuat panel-panel
        Katalog = new JPanel();
        Favorit = new JPanel();

        tabbedPane.addTab("Katalog",Katalog);
        tabbedPane.addTab("Favorit",Favorit);

        
        initFavoritTable();  // Panggil method untuk menginisialisasi tabel favorit
        loadFavoritData();   
    }
    private void initFavoritTable() {
    // Menambahkan kolom baru untuk Gambar, Deskripsi, dan Link
    tableModelFavorit = new DefaultTableModel(new Object[]{
        "Nama Budaya", "Kategori", "Provinsi", "Deskripsi", "Link Video", "Gambar"
    }, 0);
    tblFav.setModel(tableModelFavorit);
    loadFavoritData();  
}

 private void loadDataPencarian(String kategori, String provinsi) {
    try {
        // Connect to the database
        Connection conn = koneksi.getConnection();
        
        // Corrected SQL query with table aliases
        String sql = "SELECT b.nama_budaya, k.nama_kategori, p.nama_provinsi, b.link_video, b.deskripsi, b.gambar " +
                     "FROM budaya b " +
                     "JOIN kategori k ON b.id_kategori = k.id_kategori " +
                     "JOIN provinsi p ON b.id_provinsi = p.id_provinsi " +
                     "WHERE b.id_kategori = ? AND b.id_provinsi = ?";

        PreparedStatement pst = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        pst.setString(1, kategori);  // Set category (id_kategori)
        pst.setString(2, provinsi);   // Set province (id_provinsi)

        rsHasilPencarian = pst.executeQuery(); // Execute the query

        if (rsHasilPencarian.next()) {
            tampilkanHasil(rsHasilPencarian); // Show the first result if exists
        } else {
            JOptionPane.showMessageDialog(this, "Tidak ada data yang ditemukan!");
        }

    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Gagal mengambil data!");
    }
}


    private void loadKategoriProvinsi() {
    try {
        Connection conn = koneksi.getConnection();
        String sql = "SELECT id_kategori, id_provinsi FROM budaya";
        PreparedStatement pst = conn.prepareStatement(sql);
        ResultSet rs = pst.executeQuery();

        // Clear combo boxes before adding data
        cbKategori.removeAllItems();
        cbProvinsi.removeAllItems();

        // Menambahkan data ke ComboBox Kategori dan Provinsi
        while (rs.next()) {
            String kategori = rs.getString("id_kategori");
            String provinsi = rs.getString("id_provinsi");

            // Pastikan kategori dan provinsi belum ada
            if (!comboBoxKategoriContains(cbKategori, kategori)) {
                cbKategori.addItem(kategori);
            }
            if (!comboBoxProvinsiContains(cbProvinsi, provinsi)) {
                cbProvinsi.addItem(provinsi);
            }
        }

    } catch (Exception e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Gagal mengambil kategori dan provinsi!");
    }
}



    // Method untuk mengisi data dari database ke tabel favorit
private void loadFavoritData() {
        try {
            Connection conn = koneksi.getConnection();
            String sql = "SELECT f.id_favorit, b.nama_budaya,b.deskripsi,b.link_video, k.nama_kategori, p.nama_provinsi " +
                         "FROM favorit f " +
                         "JOIN budaya b ON b.id_budaya = f.id_budaya " +
                         "JOIN kategori k ON k.id_kategori = b.id_kategori " +
                         "JOIN provinsi p ON p.id_provinsi = b.id_provinsi";
    
            PreparedStatement pst = conn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            
            // Kosongkan tabel sebelum mengisi ulang
            tableModelFavorit.setRowCount(0);
    
            while (rs.next()) {
                String namaBudaya = rs.getString("nama_budaya");
                String namaKategori = rs.getString("nama_kategori");
                String namaProvinsi = rs.getString("nama_provinsi");
                String Deskripsi = rs.getString("Deskripsi");
                String link = rs.getString("link_video");
    
                // Menambahkan data ke tabel
                 tableModelFavorit.addRow(new Object[]{namaBudaya, namaKategori, namaProvinsi, Deskripsi, link, null});
            }
    
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Gagal mengambil data favorit!");
        }
    }

    

    private void removeFromFavorit(String namaBudaya) {
        try {
            Connection conn = koneksi.getConnection();
            String sql = "DELETE FROM favorit WHERE id_budaya = (SELECT id_budaya FROM budaya WHERE nama_budaya = ?)";
            
            PreparedStatement pst = conn.prepareStatement(sql);
            pst.setString(1, namaBudaya);
            pst.executeUpdate();
    
            JOptionPane.showMessageDialog(this, "Budaya dihapus dari Favorit!");
            
            // Refresh data favorit setelah penghapusan
            loadFavoritData();
    
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Gagal menghapus budaya dari favorit!", "Error Database", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }


// Cek apakah kategori sudah ada di ComboBox
private boolean comboBoxKategoriContains(JComboBox comboBox, String kategori) {
    for (int i = 0; i < comboBox.getItemCount(); i++) {
        if (comboBox.getItemAt(i).equals(kategori)) {
            return true;
        }
    }
    return false;
}

// Cek apakah provinsi sudah ada di ComboBox
private boolean comboBoxProvinsiContains(JComboBox comboBox, String provinsi) {
    for (int i = 0; i < comboBox.getItemCount(); i++) {
        if (comboBox.getItemAt(i).equals(provinsi)) {
            return true;
        }
    }
    return false;
}

private void tampilkanHasil(ResultSet rs) {
    try {
        if (rs != null && rs.next()) {
            // Menampilkan data di panelDetail
            tfnama.setText(rs.getString("nama_budaya"));
            tfkategori.setText(rs.getString("nama_kategori"));
            tfprov.setText(rs.getString("nama_provinsi"));
            taLink.setText(rs.getString("link_video"));
            taDesk.setText(rs.getString("deskripsi"));

            byte[] imagePath = rs.getBytes("gambar");
            if (imagePath != null) {
                lbGambar.setIcon(new javax.swing.ImageIcon(imagePath));  // Menampilkan gambar
            } else {
                lbGambar.setIcon(null);  // Jika tidak ada gambar
            }

        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Terjadi kesalahan saat menampilkan detail.", "Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
}





    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel5 = new javax.swing.JLabel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        Katalog = new javax.swing.JPanel();
        PanelHasil = new javax.swing.JPanel();
        lbGambar = new javax.swing.JLabel();
        tfnama = new javax.swing.JTextField();
        tfkategori = new javax.swing.JTextField();
        tfprov = new javax.swing.JTextField();
        btnFav = new javax.swing.JButton();
        btnsebelumnya = new javax.swing.JButton();
        btnNext = new javax.swing.JButton();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        taDesk = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        taLink = new javax.swing.JTextArea();
        jLabel6 = new javax.swing.JLabel();
        Detail = new javax.swing.JPanel();
        tfnamabudaya = new javax.swing.JTextField();
        tfkategoribudaya = new javax.swing.JTextField();
        jScrollPane4 = new javax.swing.JScrollPane();
        talink = new javax.swing.JTextArea();
        jScrollPane5 = new javax.swing.JScrollPane();
        tadeskripsi = new javax.swing.JTextArea();
        btnfav = new javax.swing.JButton();
        btntutup = new javax.swing.JButton();
        lblgambar = new javax.swing.JLabel();
        Tfprov = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        Favorit = new javax.swing.JPanel();
        jLabel15 = new javax.swing.JLabel();
        tfpencarian = new javax.swing.JTextField();
        btncari = new javax.swing.JButton();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblFav = new javax.swing.JTable();
        btnhapus = new javax.swing.JButton();
        btnkeluar = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        PanelPencarian = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        cbKategori = new javax.swing.JComboBox<>();
        cbProvinsi = new javax.swing.JComboBox<>();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        buttoncari = new javax.swing.JButton();

        jLabel5.setText("jLabel5");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));

        jTabbedPane1.setBackground(new java.awt.Color(255, 255, 255));

        Katalog.setLayout(new java.awt.CardLayout());

        PanelHasil.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbGambar.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbGambar.setForeground(new java.awt.Color(255, 255, 255));
        PanelHasil.add(lbGambar, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 20, 200, 170));

        tfnama.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                tfnamaActionPerformed(evt);
            }
        });
        PanelHasil.add(tfnama, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 50, 149, -1));
        PanelHasil.add(tfkategori, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 90, 149, -1));
        PanelHasil.add(tfprov, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 140, 149, -1));

        btnFav.setText("Favorit");
        btnFav.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFavActionPerformed(evt);
            }
        });
        PanelHasil.add(btnFav, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 240, -1, -1));

        btnsebelumnya.setText("Previous");
        btnsebelumnya.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnsebelumnyaActionPerformed(evt);
            }
        });
        PanelHasil.add(btnsebelumnya, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 430, -1, -1));

        btnNext.setText("Next");
        btnNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextActionPerformed(evt);
            }
        });
        PanelHasil.add(btnNext, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 430, -1, -1));

        jLabel18.setText("Nama");
        PanelHasil.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 50, -1, -1));

        jLabel19.setText("Kategori");
        PanelHasil.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 90, -1, -1));

        jLabel20.setText("Provinsi");
        PanelHasil.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 130, -1, -1));

        taDesk.setColumns(5);
        taDesk.setRows(5);
        jScrollPane1.setViewportView(taDesk);

        PanelHasil.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 260, 290, 120));

        jLabel1.setText("Link");
        PanelHasil.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 190, -1, -1));

        taLink.setColumns(20);
        taLink.setRows(5);
        jScrollPane2.setViewportView(taLink);

        PanelHasil.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(400, 190, 220, 50));

        jLabel6.setIcon(new javax.swing.ImageIcon("C:\\Users\\HP\\Downloads\\bg biruu.jpg")); // NOI18N
        PanelHasil.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, 460));

        Katalog.add(PanelHasil, "card2");

        jTabbedPane1.addTab("Katalog Budaya", Katalog);

        Detail.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        Detail.add(tfnamabudaya, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 20, 280, -1));
        Detail.add(tfkategoribudaya, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 60, 280, -1));

        talink.setColumns(20);
        talink.setRows(5);
        jScrollPane4.setViewportView(talink);

        Detail.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 180, 280, 40));

        tadeskripsi.setColumns(20);
        tadeskripsi.setRows(5);
        jScrollPane5.setViewportView(tadeskripsi);

        Detail.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 240, 280, 110));

        btnfav.setText("Favorit");
        btnfav.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnfavActionPerformed(evt);
            }
        });
        Detail.add(btnfav, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 390, -1, -1));

        btntutup.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        btntutup.setText("Oke");
        Detail.add(btntutup, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 420, -1, -1));
        Detail.add(lblgambar, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 60, 170, 150));

        Tfprov.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TfprovActionPerformed(evt);
            }
        });
        Detail.add(Tfprov, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 100, 280, 20));

        jLabel9.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel9.setText("Link :");
        Detail.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(380, 160, 70, -1));

        jLabel7.setIcon(new javax.swing.ImageIcon("C:\\Users\\HP\\Downloads\\oldbook.jpg")); // NOI18N
        Detail.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jTabbedPane1.addTab("Detail", Detail);

        Favorit.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel15.setText("Pencarian :");
        Favorit.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(23, 20, -1, -1));
        Favorit.add(tfpencarian, new org.netbeans.lib.awtextra.AbsoluteConstraints(139, 17, 190, -1));

        btncari.setText("Cari");
        Favorit.add(btncari, new org.netbeans.lib.awtextra.AbsoluteConstraints(401, 17, -1, -1));

        tblFav.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane3.setViewportView(tblFav);

        Favorit.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 46, 584, 338));

        btnhapus.setText("Hapus");
        btnhapus.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnhapusActionPerformed(evt);
            }
        });
        Favorit.add(btnhapus, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 402, -1, -1));

        btnkeluar.setText("Keluar");
        Favorit.add(btnkeluar, new org.netbeans.lib.awtextra.AbsoluteConstraints(552, 402, -1, -1));

        jLabel10.setIcon(new javax.swing.ImageIcon("C:\\Users\\HP\\Downloads\\blurry.jpg")); // NOI18N
        Favorit.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        jTabbedPane1.addTab("Favorit", Favorit);

        PanelPencarian.setBackground(new java.awt.Color(199, 176, 154));
        PanelPencarian.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setText("SELAMAT DATANG DI KATALOG EKSPLORASI BUDAYA!!");
        PanelPencarian.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 0, 308, 20));

        cbKategori.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        PanelPencarian.add(cbKategori, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 30, 146, -1));

        cbProvinsi.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        PanelPencarian.add(cbProvinsi, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 60, 146, -1));

        jLabel2.setText("Kategori");
        PanelPencarian.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 40, 55, -1));

        jLabel4.setText("Provinsi");
        PanelPencarian.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 70, 55, -1));

        buttoncari.setText("Cari");
        buttoncari.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttoncariActionPerformed(evt);
            }
        });
        PanelPencarian.add(buttoncari, new org.netbeans.lib.awtextra.AbsoluteConstraints(560, 120, -1, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PanelPencarian, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 664, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addComponent(PanelPencarian, javax.swing.GroupLayout.PREFERRED_SIZE, 147, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 497, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnhapusActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnhapusActionPerformed

        int selectedRow = tblFav.getSelectedRow();
        if (selectedRow != -1) {
            String namaBudaya = (String) tblFav.getValueAt(selectedRow, 0);  // Ambil nama budaya
            removeFromFavorit(namaBudaya);  // Hapus budaya dari favorit
        } else {
            JOptionPane.showMessageDialog(this, "Pilih budaya yang ingin dihapus.");
        }
    }//GEN-LAST:event_btnhapusActionPerformed

    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        try {
            if (rsHasilPencarian != null && rsHasilPencarian.next()) {
                tampilkanHasil(rsHasilPencarian);
            } else {
                JOptionPane.showMessageDialog(this, "Tidak ada data selanjutnya.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnNextActionPerformed

    private void btnsebelumnyaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnsebelumnyaActionPerformed

        try {
            if (rsHasilPencarian != null && rsHasilPencarian.previous()) {
                tampilkanHasil(rsHasilPencarian);
            } else {
                JOptionPane.showMessageDialog(this, "Tidak ada data sebelumnya.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnsebelumnyaActionPerformed

    private void btnFavActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFavActionPerformed

        try {
            Connection conn = koneksi.getConnection();

            // Ambil id_budaya berdasarkan nama budaya yang dipilih pengguna
            String namaBudaya = tfnama.getText();  // Nama budaya yang ditampilkan di JTextField
            int idBudaya = getIdBudaya(namaBudaya, conn);

            if (idBudaya != -1) {
                // Jika id_budaya valid, tambahkan ke tabel favorit
                String sql = "INSERT INTO favorit (id_budaya) VALUES (?)";
                PreparedStatement pst = conn.prepareStatement(sql);
                pst.setInt(1, idBudaya);
                pst.executeUpdate();

                JOptionPane.showMessageDialog(null, "Ditambahkan ke Favorit!");
            } else {
                JOptionPane.showMessageDialog(null, "Budaya tidak ditemukan, tidak bisa menambahkan ke Favorit.");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Terjadi kesalahan saat menambahkan ke favorit. Silakan coba lagi.", "Database Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }//GEN-LAST:event_btnFavActionPerformed

    private void tfnamaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_tfnamaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_tfnamaActionPerformed

    private void buttoncariActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttoncariActionPerformed
        String kategori = cbKategori.getSelectedItem().toString();
        String provinsi = cbProvinsi.getSelectedItem().toString();
        loadDataPencarian(kategori, provinsi);
    }//GEN-LAST:event_buttoncariActionPerformed

    private void TfprovActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TfprovActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_TfprovActionPerformed

    private void btnfavActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnfavActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnfavActionPerformed
private int getIdBudaya(String namaBudaya, Connection conn) {
    try {
        String sql = "SELECT id_budaya FROM budaya WHERE nama_budaya = ?";
        PreparedStatement pst = conn.prepareStatement(sql);
        pst.setString(1, namaBudaya);
        ResultSet rs = pst.executeQuery();
        if (rs.next()) {
            return rs.getInt("id_budaya");
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(null, "Terjadi kesalahan saat mengambil data budaya dari database. Silakan coba lagi.", "Database Error", JOptionPane.ERROR_MESSAGE);
        e.printStackTrace();
    }
    return -1;  // Kembalikan -1 jika tidak ditemukan atau terjadi kesalahan
}


    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DashboardUser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DashboardUser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DashboardUser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DashboardUser.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DashboardUser().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Detail;
    private javax.swing.JPanel Favorit;
    private javax.swing.JPanel Katalog;
    private javax.swing.JPanel PanelHasil;
    private javax.swing.JPanel PanelPencarian;
    private javax.swing.JTextField Tfprov;
    private javax.swing.JButton btnFav;
    private javax.swing.JButton btnNext;
    private javax.swing.JButton btncari;
    private javax.swing.JButton btnfav;
    private javax.swing.JButton btnhapus;
    private javax.swing.JButton btnkeluar;
    private javax.swing.JButton btnsebelumnya;
    private javax.swing.JButton btntutup;
    private javax.swing.JButton buttoncari;
    private javax.swing.JComboBox<String> cbKategori;
    private javax.swing.JComboBox<String> cbProvinsi;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel lbGambar;
    private javax.swing.JLabel lblgambar;
    private javax.swing.JTextArea taDesk;
    private javax.swing.JTextArea taLink;
    private javax.swing.JTextArea tadeskripsi;
    private javax.swing.JTextArea talink;
    private javax.swing.JTable tblFav;
    private javax.swing.JTextField tfkategori;
    private javax.swing.JTextField tfkategoribudaya;
    private javax.swing.JTextField tfnama;
    private javax.swing.JTextField tfnamabudaya;
    private javax.swing.JTextField tfpencarian;
    private javax.swing.JTextField tfprov;
    // End of variables declaration//GEN-END:variables
}
