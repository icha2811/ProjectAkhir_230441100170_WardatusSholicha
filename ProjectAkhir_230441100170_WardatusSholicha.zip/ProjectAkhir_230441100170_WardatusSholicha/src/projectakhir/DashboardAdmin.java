/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package projectakhir;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.*;
import java.sql.*;
import java.io.*;

public class DashboardAdmin extends javax.swing.JFrame {
    private DefaultTableModel tabelBudaya;
    private byte[] imageBytes = null; // Menyimpan gambar dalam format byte array
    private Connection conn;
    

    public DashboardAdmin() {
        initComponents();
        conn = koneksi.getConnection();

        if (conn == null) {
            JOptionPane.showMessageDialog(this, "Koneksi ke database gagal!", "Error", JOptionPane.ERROR_MESSAGE);
        }

        // Set up model untuk tabel Budaya
        tabelBudaya = new DefaultTableModel();
        tblBudaya.setModel(tabelBudaya);
        tabelBudaya.addColumn("ID Budaya");
        tabelBudaya.addColumn("Gambar");
        tabelBudaya.addColumn("Nama Kategori");
        tabelBudaya.addColumn("Nama Provinsi");
        tabelBudaya.addColumn("Nama Budaya");
        tabelBudaya.addColumn("Link Video");
        tabelBudaya.addColumn("Deskripsi");
        tblBudaya.setRowHeight(50); // Set tinggi baris untuk menampilkan gambar
        tblBudaya.getColumnModel().getColumn(1).setCellRenderer(new ImageRenderer());

        loadBudaya(); // Memuat data budaya ke tabel
        loadComboBox(); // Memuat data ke ComboBox
        tblBudaya.addMouseListener(new java.awt.event.MouseAdapter() {
    public void mouseClicked(java.awt.event.MouseEvent evt) {
        int selectedRow = tblBudaya.getSelectedRow();
        if (selectedRow != -1) { // Pastikan ada baris yang dipilih
            // Ambil ID Budaya dari tabel
            String idBudaya = tblBudaya.getValueAt(selectedRow, 0).toString(); 
            loadDataForEdit(idBudaya); 
            Admin.setSelectedIndex(2); 
        }
    }
});
    }
private void loadComboBox() {
    try {
        // Mengisi ComboBox Kategori
        String sqlKategori = "SELECT id_kategori, nama_kategori FROM kategori";
        PreparedStatement psKategori = conn.prepareStatement(sqlKategori);
        ResultSet rsKategori = psKategori.executeQuery();
        cbKategori.removeAllItems(); // Menghapus item lama
        while (rsKategori.next()) {
            String idKategori = rsKategori.getString("id_kategori");
            String namaKategori = rsKategori.getString("nama_kategori");
            cbKategori.addItem(namaKategori + " (" + idKategori + ")"); // Menyimpan nama dan ID
        }

        // Mengisi ComboBox Provinsi
        String sqlProvinsi = "SELECT id_provinsi, nama_provinsi FROM provinsi";
        PreparedStatement psProvinsi = conn.prepareStatement(sqlProvinsi);
        ResultSet rsProvinsi = psProvinsi.executeQuery();
        cbProvinsi.removeAllItems(); // Menghapus item lama
        while (rsProvinsi.next()) {
            String idProvinsi = rsProvinsi.getString("id_provinsi");
            String namaProvinsi = rsProvinsi.getString("nama_provinsi");
            cbProvinsi.addItem(namaProvinsi + " (" + idProvinsi + ")"); // Menyimpan nama dan ID
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
    private void loadBudaya() {
        // Clear existing rows
        tabelBudaya.setRowCount(0);

        try {
            String sql = "SELECT b.id_budaya, b.nama_budaya, k.nama_kategori, p.nama_provinsi, b.deskripsi, b.link_video, b.gambar " +
                         "FROM budaya b " +
                         "JOIN kategori k ON b.id_kategori = k.id_kategori " +
                         "JOIN provinsi p ON b.id_provinsi = p.id_provinsi";
            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                int idBudaya = rs.getInt("id_budaya");
                String namaBudaya = rs.getString("nama_budaya");
                String namaKategori = rs.getString("nama_kategori");
                String namaProvinsi = rs.getString("nama_provinsi");
                String deskripsi = rs.getString("deskripsi");
                String linkVideo = rs.getString("link_video");
                byte[] gambar = rs.getBytes("gambar");

                tabelBudaya.addRow(new Object[]{idBudaya, gambar, namaKategori, namaProvinsi, namaBudaya, linkVideo, deskripsi});
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading data: " + e.getMessage());
        }
    }


 private void btnPilihGambarActionPerformed(java.awt.event.ActionEvent evt) {
    JFileChooser fileChooser = new JFileChooser();
    fileChooser.setDialogTitle("Pilih Gambar Budaya");
    FileNameExtensionFilter filter = new FileNameExtensionFilter("Image files", "jpg", "jpeg", "png");
    fileChooser.setFileFilter(filter);

    int result = fileChooser.showOpenDialog(this);
    if (result == JFileChooser.APPROVE_OPTION) {
        File file = fileChooser.getSelectedFile();
        String filePath = file.getAbsolutePath();
        ImageIcon icon = new ImageIcon(filePath);

        // Resize image untuk ditampilkan di JLabel
        Image image = icon.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
        
        // Menampilkan gambar di label yang sesuai
        if (Admin.getSelectedIndex() == 1) { // Jika berada di tab Tambah
            lblGambar.setIcon(new ImageIcon(image));
        } else if (Admin.getSelectedIndex() == 2) { // Jika berada di tab Edit
            lblgambar.setIcon(new ImageIcon(image));
        }

        // Convert gambar menjadi byte[] untuk disimpan di database
        try {
            FileInputStream fis = new FileInputStream(file);
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            byte[] buffer = new byte[1024];
            int bytesRead;
            while ((bytesRead = fis.read(buffer)) != -1) {
                bos.write(buffer, 0, bytesRead);
            }
            imageBytes = bos.toByteArray();
            fis.close();
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error membaca gambar: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

    private void loadDataForEdit(String idBudaya) {
        try {
            String sql = "SELECT * FROM budaya WHERE id_budaya = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, idBudaya);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                tfid.setText(rs.getString("id_budaya"));
                tfnama.setText(rs.getString("nama_budaya"));
                cbkategori.setSelectedItem(rs.getString("id_kategori")); // Mengambil nama kategori berdasarkan ID
                cbprov.setSelectedItem(rs.getString("id_provinsi")); // Mengambil nama provinsi berdasarkan ID
                tadesk.setText(rs.getString("deskripsi"));
                talink.setText(rs.getString("link_video"));

                // Menampilkan gambar
                byte[] imgBytes = rs.getBytes("gambar");
                if (imgBytes != null) {
                    ImageIcon icon = new ImageIcon(imgBytes);
                    Image image = icon.getImage().getScaledInstance(150, 150, Image.SCALE_SMOOTH);
                    lblgambar.setIcon(new ImageIcon(image)); // Menampilkan gambar di label Edit
                    imageBytes = imgBytes; // Simpan gambar dalam format byte array
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

   private void tambahBudaya() {
    String namaBudaya = tfNama.getText();
    String kategori = cbKategori.getSelectedItem().toString();
    String provinsi = cbProvinsi.getSelectedItem().toString();
    String deskripsi = taDeskripsi.getText();
    String linkVideo = taLink.getText();

    // Cek apakah semua field terisi
    if (namaBudaya.isEmpty() || kategori.isEmpty() || provinsi.isEmpty() || deskripsi.isEmpty() || imageBytes == null) {
        JOptionPane.showMessageDialog(this, "Semua field harus diisi dan gambar harus dipilih!", "Peringatan", JOptionPane.WARNING_MESSAGE);
        return; // Hentikan eksekusi jika ada input kosong
    }

    try {
        String sql = "INSERT INTO budaya (nama_budaya, id_kategori, id_provinsi, deskripsi, gambar, link_video) VALUES (?, ?, ?, ?, ?, ?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, namaBudaya);
        ps.setString(2, kategori); // Anda mungkin perlu mendapatkan ID kategori berdasarkan nama
        ps.setString(3, provinsi); // Anda mungkin perlu mendapatkan ID provinsi berdasarkan nama
        ps.setString(4, deskripsi);
        ps.setBytes(5, imageBytes); // Menyimpan gambar dalam bentuk byte[]
        ps.setString(6, linkVideo);

        int rowsAffected = ps.executeUpdate(); // Eksekusi query untuk menambahkan data
        if (rowsAffected > 0) {
            JOptionPane.showMessageDialog(this, "Data budaya berhasil ditambahkan!");
            loadBudaya(); // Refresh tabel setelah menambahkan data
        } else {
            JOptionPane.showMessageDialog(this, "Gagal menambahkan data budaya.", "Gagal", JOptionPane.ERROR_MESSAGE);
        }
    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error menambahkan budaya: " + e.getMessage());
    }
}

 private void updateBudaya() {
        String idBudaya = tfid.getText();
        String namaBudaya = tfnama.getText();
        String deskripsi = tadesk.getText();
        String linkVideo = talink.getText();

        try (Connection conn = koneksi.getConnection()) {
            String sql = "UPDATE budaya SET nama_budaya = ?, deskripsi = ?, link_video = ? WHERE id_budaya = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, namaBudaya);
            ps.setString(2, deskripsi);
            ps.setString(3, linkVideo);
            ps.setString(4, idBudaya);

            int rowsAffected = ps.executeUpdate(); // Mengeksekusi query dan mendapatkan jumlah baris yang terpengaruh
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Data budaya berhasil diperbarui!", "Berhasil", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Gagal memperbarui data budaya.", "Gagal", JOptionPane.ERROR_MESSAGE);
            }

            loadBudaya(); // Refresh tabel setelah update data
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    private void deleteBudaya() {
        String idBudaya = tfId.getText();

        try (Connection conn = koneksi.getConnection()) {
            String sql = "DELETE FROM budaya WHERE id_budaya = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, idBudaya);

            int rowsAffected = ps.executeUpdate(); // Mengeksekusi query dan mendapatkan jumlah baris yang terpengaruh
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(null, "Data budaya berhasil dihapus!", "Berhasil", JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null, "Gagal menghapus data budaya.", "Gagal", JOptionPane.ERROR_MESSAGE);
            }

            loadBudaya(); // Refresh tabel setelah menghapus data
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Terjadi kesalahan: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    // Renderer untuk menampilkan gambar pada JTable
    private class ImageRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
            JLabel label = new JLabel();
            if (value != null) {
                byte[] imageBytes = (byte[]) value;
                ImageIcon icon = new ImageIcon(imageBytes);
                Image scaledImage = icon.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
                label.setIcon(new ImageIcon(scaledImage));
            }
            return label;
        }
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    // </editor-fold>



  

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Admin = new javax.swing.JTabbedPane();
        Dashboard = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblBudaya = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        tfpencarian = new javax.swing.JTextField();
        btncari = new javax.swing.JButton();
        btnTambah = new javax.swing.JButton();
        btnEdit = new javax.swing.JButton();
        btnhapus = new javax.swing.JButton();
        btnKeluar = new javax.swing.JButton();
        jLabel18 = new javax.swing.JLabel();
        Tambah = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        tfId = new javax.swing.JTextField();
        tfNama = new javax.swing.JTextField();
        cbKategori = new javax.swing.JComboBox<>();
        cbProvinsi = new javax.swing.JComboBox<>();
        jScrollPane2 = new javax.swing.JScrollPane();
        taDeskripsi = new javax.swing.JTextArea();
        jLabel8 = new javax.swing.JLabel();
        fcGambar = new javax.swing.JFileChooser();
        lblGambar = new javax.swing.JLabel();
        btnSimpan = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        taLink = new javax.swing.JTextArea();
        btnBatal = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        Edit = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        tfid = new javax.swing.JTextField();
        tfnama = new javax.swing.JTextField();
        cbkategori = new javax.swing.JComboBox<>();
        cbprov = new javax.swing.JComboBox<>();
        jScrollPane3 = new javax.swing.JScrollPane();
        tadesk = new javax.swing.JTextArea();
        jLabel15 = new javax.swing.JLabel();
        fcgambar = new javax.swing.JFileChooser();
        lblgambar = new javax.swing.JLabel();
        btnUpdate = new javax.swing.JButton();
        jScrollPane5 = new javax.swing.JScrollPane();
        talink = new javax.swing.JTextArea();
        btnReset = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jLabel16 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        Dashboard.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tblBudaya.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4", "Title 5", "Title 6", "Title 7", "Title 8"
            }
        ));
        jScrollPane1.setViewportView(tblBudaya);

        Dashboard.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 70, 566, 330));

        jLabel2.setText("Cari :");
        Dashboard.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(16, 16, 53, -1));
        Dashboard.add(tfpencarian, new org.netbeans.lib.awtextra.AbsoluteConstraints(75, 16, 119, -1));

        btncari.setText("Telusuri");
        Dashboard.add(btncari, new org.netbeans.lib.awtextra.AbsoluteConstraints(206, 16, -1, -1));

        btnTambah.setText("Tambah");
        btnTambah.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTambahActionPerformed(evt);
            }
        });
        Dashboard.add(btnTambah, new org.netbeans.lib.awtextra.AbsoluteConstraints(369, 16, -1, -1));

        btnEdit.setText("Edit");
        btnEdit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditActionPerformed(evt);
            }
        });
        Dashboard.add(btnEdit, new org.netbeans.lib.awtextra.AbsoluteConstraints(479, 16, -1, -1));

        btnhapus.setText("Hapus");
        Dashboard.add(btnhapus, new org.netbeans.lib.awtextra.AbsoluteConstraints(16, 423, -1, -1));

        btnKeluar.setText("Keluar");
        Dashboard.add(btnKeluar, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 420, -1, -1));

        jLabel18.setIcon(new javax.swing.ImageIcon("C:\\Users\\HP\\Downloads\\viber.jpg")); // NOI18N
        jLabel18.setText("jLabel18");
        Dashboard.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 670, 490));

        Admin.addTab("Dashboard", Dashboard);

        Tambah.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel3.setText("ID");
        Tambah.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(130, 80, 30, -1));

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel4.setText("Kategori");
        Tambah.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 90, 78, -1));

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel5.setText("Provinsi");
        Tambah.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 170, -1, -1));

        jLabel6.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel6.setText("Nama");
        Tambah.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 120, -1, -1));

        jLabel7.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel7.setText("Deskripsi");
        Tambah.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 130, -1, -1));
        Tambah.add(tfId, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 80, 170, -1));
        Tambah.add(tfNama, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 120, 170, -1));

        cbKategori.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        Tambah.add(cbKategori, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 170, 170, -1));

        cbProvinsi.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        Tambah.add(cbProvinsi, new org.netbeans.lib.awtextra.AbsoluteConstraints(470, 90, 170, -1));

        taDeskripsi.setColumns(20);
        taDeskripsi.setRows(5);
        jScrollPane2.setViewportView(taDeskripsi);

        Tambah.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 160, -1, 95));

        jLabel8.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel8.setText("Link");
        Tambah.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 220, 48, -1));

        fcGambar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fcGambarActionPerformed(evt);
            }
        });
        Tambah.add(fcGambar, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 250, 440, 170));
        Tambah.add(lblGambar, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 290, 120, 100));

        btnSimpan.setText("Simpan");
        btnSimpan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSimpanActionPerformed(evt);
            }
        });
        Tambah.add(btnSimpan, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 420, -1, -1));

        taLink.setColumns(20);
        taLink.setRows(5);
        jScrollPane4.setViewportView(taLink);

        Tambah.add(jScrollPane4, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 210, -1, 40));

        btnBatal.setText("Batal");
        btnBatal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBatalActionPerformed(evt);
            }
        });
        Tambah.add(btnBatal, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 420, -1, -1));

        jButton1.setText("Tambah");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        Tambah.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 420, -1, -1));

        jLabel9.setIcon(new javax.swing.ImageIcon("C:\\Users\\HP\\Downloads\\flow.jpg")); // NOI18N
        Tambah.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        Admin.addTab("Tambah", Tambah);

        Edit.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel10.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel10.setText("ID");
        Edit.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 80, 30, -1));

        jLabel11.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel11.setText("Kategori :");
        Edit.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 110, 70, -1));

        jLabel12.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel12.setText("Provinsi :");
        Edit.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 160, -1, -1));

        jLabel13.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel13.setText("Nama :");
        Edit.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 120, -1, -1));

        jLabel14.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel14.setText("Deskripsi");
        Edit.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 140, -1, -1));
        Edit.add(tfid, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 120, 150, -1));
        Edit.add(tfnama, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 80, 90, -1));

        cbkategori.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        Edit.add(cbkategori, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 160, 170, -1));

        cbprov.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        Edit.add(cbprov, new org.netbeans.lib.awtextra.AbsoluteConstraints(460, 110, 170, -1));

        tadesk.setColumns(20);
        tadesk.setRows(5);
        jScrollPane3.setViewportView(tadesk);

        Edit.add(jScrollPane3, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 160, -1, 103));

        jLabel15.setFont(new java.awt.Font("Times New Roman", 1, 14)); // NOI18N
        jLabel15.setText("Link :");
        Edit.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 210, 48, -1));

        fcgambar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                fcgambarActionPerformed(evt);
            }
        });
        Edit.add(fcgambar, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 260, 450, 150));
        Edit.add(lblgambar, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 30, 150, 100));

        btnUpdate.setText("Update");
        btnUpdate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnUpdateActionPerformed(evt);
            }
        });
        Edit.add(btnUpdate, new org.netbeans.lib.awtextra.AbsoluteConstraints(511, 378, -1, -1));

        talink.setColumns(20);
        talink.setRows(5);
        jScrollPane5.setViewportView(talink);

        Edit.add(jScrollPane5, new org.netbeans.lib.awtextra.AbsoluteConstraints(110, 210, -1, 39));

        btnReset.setText("Reset");
        btnReset.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnResetActionPerformed(evt);
            }
        });
        Edit.add(btnReset, new org.netbeans.lib.awtextra.AbsoluteConstraints(511, 413, -1, -1));

        jButton2.setText("Tambah");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        Edit.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 420, -1, -1));

        jLabel16.setIcon(new javax.swing.ImageIcon("C:\\Users\\HP\\Downloads\\flower.jpg")); // NOI18N
        Edit.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, -1, -1));

        Admin.addTab("Edit", Edit);

        getContentPane().add(Admin, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 60, 670, 500));

        jLabel1.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel1.setText("Halo!             Selamat Datang Di Dashboard Admin");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 0, -1, 30));

        jLabel17.setText("🖐️🖐️🖐");
        getContentPane().add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 10, -1, -1));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void fcgambarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fcgambarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fcgambarActionPerformed

    private void btnResetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnResetActionPerformed
       Admin.setSelectedIndex(0);
    }//GEN-LAST:event_btnResetActionPerformed

    private void btnTambahActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTambahActionPerformed
    Admin.setSelectedIndex(1);
    }//GEN-LAST:event_btnTambahActionPerformed

    private void btnEditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditActionPerformed
       Admin.setSelectedIndex(2);
    }//GEN-LAST:event_btnEditActionPerformed

    private void btnSimpanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSimpanActionPerformed
     tambahBudaya();
    }//GEN-LAST:event_btnSimpanActionPerformed

    private void btnUpdateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnUpdateActionPerformed
    updateBudaya();
    }//GEN-LAST:event_btnUpdateActionPerformed

    private void btnBatalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBatalActionPerformed
       Admin.setSelectedIndex(0);
    }//GEN-LAST:event_btnBatalActionPerformed

    private void fcGambarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_fcGambarActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_fcGambarActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
    tambahBudaya();
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
    tambahBudaya();
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DashboardAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DashboardAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DashboardAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DashboardAdmin.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DashboardAdmin().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTabbedPane Admin;
    private javax.swing.JPanel Dashboard;
    private javax.swing.JPanel Edit;
    private javax.swing.JPanel Tambah;
    private javax.swing.JButton btnBatal;
    private javax.swing.JButton btnEdit;
    private javax.swing.JButton btnKeluar;
    private javax.swing.JButton btnReset;
    private javax.swing.JButton btnSimpan;
    private javax.swing.JButton btnTambah;
    private javax.swing.JButton btnUpdate;
    private javax.swing.JButton btncari;
    private javax.swing.JButton btnhapus;
    private javax.swing.JComboBox<String> cbKategori;
    private javax.swing.JComboBox<String> cbProvinsi;
    private javax.swing.JComboBox<String> cbkategori;
    private javax.swing.JComboBox<String> cbprov;
    private javax.swing.JFileChooser fcGambar;
    private javax.swing.JFileChooser fcgambar;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JLabel lblGambar;
    private javax.swing.JLabel lblgambar;
    private javax.swing.JTextArea taDeskripsi;
    private javax.swing.JTextArea taLink;
    private javax.swing.JTextArea tadesk;
    private javax.swing.JTextArea talink;
    private javax.swing.JTable tblBudaya;
    private javax.swing.JTextField tfId;
    private javax.swing.JTextField tfNama;
    private javax.swing.JTextField tfid;
    private javax.swing.JTextField tfnama;
    private javax.swing.JTextField tfpencarian;
    // End of variables declaration//GEN-END:variables
}


